#include <stdio.h>
#include <conio.h>

void main()
{
	char a='z';
	char b='y';
	char c[]={a,b,'\0'};
//	printf("%s",c);
puts(c);
}
